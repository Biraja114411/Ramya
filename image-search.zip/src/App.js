import React, { useState } from 'react';
import axios from 'axios';
import logo from './logo.svg';
import './SearchResults.css';
import SearchResults from './SearchResults';

function App() {
  const [results, setResults] = useState([]);
  const [searchString, setSearchString] = useState('');

  const getResults = function (ss) {
    axios.get('https://api.unsplash.com/search/photos/', {
      params: {
        'query': ss,
        // client_id: '2bWr8JILa0SvwB13R117MJgDWqyQgSv9wRGx21-NyW0',
        'client_id': 'cyW6J_QZ1HlJtju2orbccuWRPOeULwK1jbFtNvqQbX8',
        'per_page': 25
      }
    })
      .then(function (response) {
        console.log(response);
        setResults(response.data.results);
      })
  }
  const search = function (e) {
    e.preventDefault();
    if (!!searchString) {
      getResults(searchString);
    } else {
      setResults([]);
    }
  }

  const handleChange = function (e) {
    setSearchString(e.target.value || '');
  }

  return (
    <div className="App">
      <form onSubmit={search.bind(this)}>
        <input type="text" onChange={handleChange.bind(this)} />
        <button type="submit">Search</button>
      </form>
      <SearchResults results={results} />
    </div>
  );
}

export default App;
